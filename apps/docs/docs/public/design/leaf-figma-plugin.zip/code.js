// Generated from the runtime theme sources; no network access.
const leafPalettes = {"light":{"primary-alpha-10":{"r":0.11764705882352941,"g":0.5882352941176471,"b":0.30980392156862746,"a":0.1},"primary-alpha-12":{"r":0.11764705882352941,"g":0.5882352941176471,"b":0.30980392156862746,"a":0.12},"primary-alpha-16":{"r":0.11764705882352941,"g":0.5882352941176471,"b":0.30980392156862746,"a":0.16},"primary-alpha-20":{"r":0.11764705882352941,"g":0.5882352941176471,"b":0.30980392156862746,"a":0.2},"primary-alpha-4":{"r":0.11764705882352941,"g":0.5882352941176471,"b":0.30980392156862746,"a":0.04},"primary-alpha-55":{"r":0.11764705882352941,"g":0.5882352941176471,"b":0.30980392156862746,"a":0.55},"surface-alpha-55":{"r":1,"g":1,"b":1,"a":0.55},"surface-alpha-90":{"r":1,"g":1,"b":1,"a":0.9},"text-subtle-alpha-9":{"r":0.40784313725490196,"g":0.43529411764705883,"b":0.47843137254901963,"a":0.09},"warning-alpha-16":{"r":0.9803921568627451,"g":0.6784313725490196,"b":0.0784313725490196,"a":0.16},"neutral":{"r":0.4235294117647059,"g":0.45098039215686275,"b":0.49411764705882355,"a":1},"neutral-100":{"r":0.9568627450980393,"g":0.9607843137254902,"b":0.9686274509803922,"a":1},"neutral-200":{"r":0.8901960784313725,"g":0.8980392156862745,"b":0.9098039215686274,"a":1},"neutral-300":{"r":0.7803921568627451,"g":0.796078431372549,"b":0.8196078431372549,"a":1},"neutral-400":{"r":0.6470588235294118,"g":0.6705882352941176,"b":0.7098039215686275,"a":1},"neutral-500":{"r":0.5215686274509804,"g":0.5529411764705883,"b":0.596078431372549,"a":1},"neutral-600":{"r":0.40784313725490196,"g":0.43529411764705883,"b":0.47843137254901963,"a":1},"neutral-700":{"r":0.3058823529411765,"g":0.3254901960784314,"b":0.35294117647058826,"a":1},"neutral-800":{"r":0.21176470588235294,"g":0.2196078431372549,"b":0.23529411764705882,"a":1},"neutral-900":{"r":0.12156862745098039,"g":0.12156862745098039,"b":0.12549019607843137,"a":1},"text":{"r":0.12156862745098039,"g":0.12156862745098039,"b":0.12549019607843137,"a":1},"text-muted":{"r":0.40784313725490196,"g":0.43529411764705883,"b":0.47843137254901963,"a":1},"text-subtle":{"r":0.40784313725490196,"g":0.43529411764705883,"b":0.47843137254901963,"a":1},"surface":{"r":1,"g":1,"b":1,"a":1},"surface-muted":{"r":0.9568627450980393,"g":0.9607843137254902,"b":0.9686274509803922,"a":1},"surface-raised":{"r":1,"g":1,"b":1,"a":1},"border":{"r":0.8901960784313725,"g":0.8980392156862745,"b":0.9098039215686274,"a":1},"border-hover":{"r":0.7803921568627451,"g":0.796078431372549,"b":0.8196078431372549,"a":1},"divider":{"r":0.8901960784313725,"g":0.8980392156862745,"b":0.9098039215686274,"a":1},"option-hover":{"r":0.8901960784313725,"g":0.8980392156862745,"b":0.9098039215686274,"a":1},"primary":{"r":0.11764705882352941,"g":0.5882352941176471,"b":0.30980392156862746,"a":1},"primary-light-3":{"r":0.3843137254901961,"g":0.7137254901960784,"b":0.5176470588235295,"a":1},"primary-light-7":{"r":0.7372549019607844,"g":0.8784313725490196,"b":0.792156862745098,"a":1},"primary-light-9":{"r":0.9137254901960784,"g":0.9607843137254902,"b":0.9294117647058824,"a":1},"primary-dark-1":{"r":0.10588235294117647,"g":0.5294117647058824,"b":0.2784313725490196,"a":1},"primary-dark-3":{"r":0.08235294117647059,"g":0.4117647058823529,"b":0.21568627450980393,"a":1},"primary-dark-7":{"r":0.03529411764705882,"g":0.17647058823529413,"b":0.09411764705882353,"a":1},"primary-dark-9":{"r":0.011764705882352941,"g":0.058823529411764705,"b":0.03137254901960784,"a":1},"primary-soft":{"r":0.9137254901960784,"g":0.9607843137254902,"b":0.9294117647058824,"a":1},"primary-soft-hover":{"r":0.7372549019607844,"g":0.8784313725490196,"b":0.792156862745098,"a":1},"primary-soft-active":{"r":0.7372549019607844,"g":0.8784313725490196,"b":0.792156862745098,"a":1},"primary-border":{"r":0.7372549019607844,"g":0.8784313725490196,"b":0.792156862745098,"a":1},"primary-ink":{"r":0.08235294117647059,"g":0.4117647058823529,"b":0.21568627450980393,"a":1},"on-primary":{"r":1,"g":1,"b":1,"a":1},"primary-indicator":{"r":0.11764705882352941,"g":0.5882352941176471,"b":0.30980392156862746,"a":1},"primary-focus":{"r":0.11764705882352941,"g":0.5882352941176471,"b":0.30980392156862746,"a":1},"primary-fill-border":{"r":0,"g":0,"b":0,"a":0},"primary-active":{"r":0.10588235294117647,"g":0.5294117647058824,"b":0.2784313725490196,"a":1},"primary-ink-active":{"r":0.07450980392156863,"g":0.37254901960784315,"b":0.19607843137254902,"a":1},"primary-hover":{"r":0.20392156862745098,"g":0.6313725490196078,"b":0.3803921568627451,"a":1},"primary-ink-hover":{"r":0.08235294117647059,"g":0.4117647058823529,"b":0.21568627450980393,"a":1},"success":{"r":0.3215686274509804,"g":0.7686274509803922,"b":0.10196078431372549,"a":1},"success-light-3":{"r":0.5254901960784314,"g":0.8392156862745098,"b":0.37254901960784315,"a":1},"success-light-7":{"r":0.796078431372549,"g":0.9294117647058824,"b":0.7294117647058823,"a":1},"success-light-9":{"r":0.9333333333333333,"g":0.9764705882352941,"b":0.9098039215686274,"a":1},"success-dark-1":{"r":0.2901960784313726,"g":0.6901960784313725,"b":0.09019607843137255,"a":1},"success-dark-3":{"r":0.2235294117647059,"g":0.5372549019607843,"b":0.07058823529411765,"a":1},"success-dark-7":{"r":0.09803921568627451,"g":0.23137254901960785,"b":0.03137254901960784,"a":1},"success-dark-9":{"r":0.03137254901960784,"g":0.0784313725490196,"b":0.011764705882352941,"a":1},"success-soft":{"r":0.9333333333333333,"g":0.9764705882352941,"b":0.9098039215686274,"a":1},"success-soft-hover":{"r":0.796078431372549,"g":0.9294117647058824,"b":0.7294117647058823,"a":1},"success-soft-active":{"r":0.796078431372549,"g":0.9294117647058824,"b":0.7294117647058823,"a":1},"success-border":{"r":0.796078431372549,"g":0.9294117647058824,"b":0.7294117647058823,"a":1},"success-ink":{"r":0.09803921568627451,"g":0.23137254901960785,"b":0.03137254901960784,"a":1},"on-success":{"r":1,"g":1,"b":1,"a":1},"danger":{"r":1,"g":0.30196078431372547,"b":0.30980392156862746,"a":1},"danger-light-3":{"r":1,"g":0.5098039215686274,"b":0.5176470588235295,"a":1},"danger-light-7":{"r":1,"g":0.792156862745098,"b":0.792156862745098,"a":1},"danger-light-9":{"r":1,"g":0.9294117647058824,"b":0.9294117647058824,"a":1},"danger-dark-1":{"r":0.9019607843137255,"g":0.27058823529411763,"b":0.2784313725490196,"a":1},"danger-dark-3":{"r":0.7019607843137254,"g":0.21176470588235294,"b":0.21568627450980393,"a":1},"danger-dark-7":{"r":0.30196078431372547,"g":0.09019607843137255,"b":0.09411764705882353,"a":1},"danger-dark-9":{"r":0.10196078431372549,"g":0.03137254901960784,"b":0.03137254901960784,"a":1},"danger-soft":{"r":1,"g":0.9294117647058824,"b":0.9294117647058824,"a":1},"danger-soft-hover":{"r":1,"g":0.792156862745098,"b":0.792156862745098,"a":1},"danger-soft-active":{"r":1,"g":0.792156862745098,"b":0.792156862745098,"a":1},"danger-border":{"r":1,"g":0.792156862745098,"b":0.792156862745098,"a":1},"danger-ink":{"r":0.7019607843137254,"g":0.21176470588235294,"b":0.21568627450980393,"a":1},"on-danger":{"r":1,"g":1,"b":1,"a":1},"danger-active":{"r":0.9019607843137255,"g":0.27058823529411763,"b":0.2784313725490196,"a":1},"danger-hover":{"r":1,"g":0.37254901960784315,"b":0.3803921568627451,"a":1},"warning":{"r":0.9803921568627451,"g":0.6784313725490196,"b":0.0784313725490196,"a":1},"warning-light-3":{"r":0.9882352941176471,"g":0.7764705882352941,"b":0.3568627450980392,"a":1},"warning-light-7":{"r":0.996078431372549,"g":0.9019607843137255,"b":0.7254901960784313,"a":1},"warning-light-9":{"r":1,"g":0.9686274509803922,"b":0.9098039215686274,"a":1},"warning-dark-1":{"r":0.8823529411764706,"g":0.611764705882353,"b":0.07058823529411765,"a":1},"warning-dark-3":{"r":0.6862745098039216,"g":0.4745098039215686,"b":0.054901960784313725,"a":1},"warning-dark-7":{"r":0.29411764705882354,"g":0.20392156862745098,"b":0.023529411764705882,"a":1},"warning-dark-9":{"r":0.09803921568627451,"g":0.06666666666666667,"b":0.00784313725490196,"a":1},"warning-soft":{"r":1,"g":0.9686274509803922,"b":0.9098039215686274,"a":1},"warning-soft-hover":{"r":0.996078431372549,"g":0.9019607843137255,"b":0.7254901960784313,"a":1},"warning-soft-active":{"r":0.996078431372549,"g":0.9019607843137255,"b":0.7254901960784313,"a":1},"warning-border":{"r":0.996078431372549,"g":0.9019607843137255,"b":0.7254901960784313,"a":1},"warning-ink":{"r":0.29411764705882354,"g":0.20392156862745098,"b":0.023529411764705882,"a":1},"on-warning":{"r":1,"g":1,"b":1,"a":1},"info":{"r":0.08627450980392157,"g":0.4666666666666667,"b":1,"a":1},"info-light-3":{"r":0.3607843137254902,"g":0.6274509803921569,"b":1,"a":1},"info-light-7":{"r":0.7254901960784313,"g":0.8392156862745098,"b":1,"a":1},"info-light-9":{"r":0.9098039215686274,"g":0.9450980392156862,"b":1,"a":1},"info-dark-1":{"r":0.0784313725490196,"g":0.4196078431372549,"b":0.9019607843137255,"a":1},"info-dark-3":{"r":0.058823529411764705,"g":0.3254901960784314,"b":0.7019607843137254,"a":1},"info-dark-7":{"r":0.027450980392156862,"g":0.1411764705882353,"b":0.30196078431372547,"a":1},"info-dark-9":{"r":0.00784313725490196,"g":0.047058823529411764,"b":0.10196078431372549,"a":1},"info-soft":{"r":0.9098039215686274,"g":0.9450980392156862,"b":1,"a":1},"info-soft-hover":{"r":0.7254901960784313,"g":0.8392156862745098,"b":1,"a":1},"info-soft-active":{"r":0.7254901960784313,"g":0.8392156862745098,"b":1,"a":1},"info-border":{"r":0.7254901960784313,"g":0.8392156862745098,"b":1,"a":1},"info-ink":{"r":0.058823529411764705,"g":0.3254901960784314,"b":0.7019607843137254,"a":1},"on-info":{"r":1,"g":1,"b":1,"a":1}},"dark":{"primary-alpha-10":{"r":0.11764705882352941,"g":0.5882352941176471,"b":0.30980392156862746,"a":0.1},"primary-alpha-12":{"r":0.11764705882352941,"g":0.5882352941176471,"b":0.30980392156862746,"a":0.12},"primary-alpha-16":{"r":0.11764705882352941,"g":0.5882352941176471,"b":0.30980392156862746,"a":0.16},"primary-alpha-20":{"r":0.11764705882352941,"g":0.5882352941176471,"b":0.30980392156862746,"a":0.2},"primary-alpha-4":{"r":0.11764705882352941,"g":0.5882352941176471,"b":0.30980392156862746,"a":0.04},"primary-alpha-55":{"r":0.11764705882352941,"g":0.5882352941176471,"b":0.30980392156862746,"a":0.55},"surface-alpha-55":{"r":0.12156862745098039,"g":0.12156862745098039,"b":0.12549019607843137,"a":0.55},"surface-alpha-90":{"r":0.12156862745098039,"g":0.12156862745098039,"b":0.12549019607843137,"a":0.9},"text-subtle-alpha-9":{"r":0.6470588235294118,"g":0.6705882352941176,"b":0.7098039215686275,"a":0.09},"warning-alpha-16":{"r":0.9803921568627451,"g":0.6784313725490196,"b":0.0784313725490196,"a":0.16},"neutral":{"r":0.4235294117647059,"g":0.45098039215686275,"b":0.49411764705882355,"a":1},"neutral-100":{"r":0.9568627450980393,"g":0.9607843137254902,"b":0.9686274509803922,"a":1},"neutral-200":{"r":0.8901960784313725,"g":0.8980392156862745,"b":0.9098039215686274,"a":1},"neutral-300":{"r":0.7803921568627451,"g":0.796078431372549,"b":0.8196078431372549,"a":1},"neutral-400":{"r":0.6470588235294118,"g":0.6705882352941176,"b":0.7098039215686275,"a":1},"neutral-500":{"r":0.5215686274509804,"g":0.5529411764705883,"b":0.596078431372549,"a":1},"neutral-600":{"r":0.40784313725490196,"g":0.43529411764705883,"b":0.47843137254901963,"a":1},"neutral-700":{"r":0.3058823529411765,"g":0.3254901960784314,"b":0.35294117647058826,"a":1},"neutral-800":{"r":0.21176470588235294,"g":0.2196078431372549,"b":0.23529411764705882,"a":1},"neutral-900":{"r":0.12156862745098039,"g":0.12156862745098039,"b":0.12549019607843137,"a":1},"text":{"r":0.9568627450980393,"g":0.9607843137254902,"b":0.9686274509803922,"a":1},"text-muted":{"r":0.6470588235294118,"g":0.6705882352941176,"b":0.7098039215686275,"a":1},"text-subtle":{"r":0.6470588235294118,"g":0.6705882352941176,"b":0.7098039215686275,"a":1},"surface":{"r":0.12156862745098039,"g":0.12156862745098039,"b":0.12549019607843137,"a":1},"surface-muted":{"r":0.21176470588235294,"g":0.2196078431372549,"b":0.23529411764705882,"a":1},"surface-raised":{"r":0.21176470588235294,"g":0.2196078431372549,"b":0.23529411764705882,"a":1},"border":{"r":0.21176470588235294,"g":0.2196078431372549,"b":0.23529411764705882,"a":1},"border-hover":{"r":0.3058823529411765,"g":0.3254901960784314,"b":0.35294117647058826,"a":1},"divider":{"r":0.21176470588235294,"g":0.2196078431372549,"b":0.23529411764705882,"a":1},"option-hover":{"r":0.3058823529411765,"g":0.3254901960784314,"b":0.35294117647058826,"a":1},"primary":{"r":0.11764705882352941,"g":0.5882352941176471,"b":0.30980392156862746,"a":1},"primary-light-3":{"r":0.3843137254901961,"g":0.7137254901960784,"b":0.5176470588235295,"a":1},"primary-light-7":{"r":0.7372549019607844,"g":0.8784313725490196,"b":0.792156862745098,"a":1},"primary-light-9":{"r":0.9137254901960784,"g":0.9607843137254902,"b":0.9294117647058824,"a":1},"primary-dark-1":{"r":0.10588235294117647,"g":0.5294117647058824,"b":0.2784313725490196,"a":1},"primary-dark-3":{"r":0.08235294117647059,"g":0.4117647058823529,"b":0.21568627450980393,"a":1},"primary-dark-7":{"r":0.03529411764705882,"g":0.17647058823529413,"b":0.09411764705882353,"a":1},"primary-dark-9":{"r":0.011764705882352941,"g":0.058823529411764705,"b":0.03137254901960784,"a":1},"primary-soft":{"r":0.011764705882352941,"g":0.058823529411764705,"b":0.03137254901960784,"a":1},"primary-soft-hover":{"r":0.03529411764705882,"g":0.17647058823529413,"b":0.09411764705882353,"a":1},"primary-soft-active":{"r":0.03529411764705882,"g":0.17647058823529413,"b":0.09411764705882353,"a":1},"primary-border":{"r":0.03529411764705882,"g":0.17647058823529413,"b":0.09411764705882353,"a":1},"primary-ink":{"r":0.3843137254901961,"g":0.7137254901960784,"b":0.5176470588235295,"a":1},"on-primary":{"r":1,"g":1,"b":1,"a":1},"primary-indicator":{"r":0.11764705882352941,"g":0.5882352941176471,"b":0.30980392156862746,"a":1},"primary-focus":{"r":0.11764705882352941,"g":0.5882352941176471,"b":0.30980392156862746,"a":1},"primary-fill-border":{"r":0,"g":0,"b":0,"a":0},"primary-active":{"r":0.10588235294117647,"g":0.5294117647058824,"b":0.2784313725490196,"a":1},"primary-ink-active":{"r":0.4470588235294118,"g":0.7411764705882353,"b":0.5647058823529412,"a":1},"primary-hover":{"r":0.20392156862745098,"g":0.6313725490196078,"b":0.3803921568627451,"a":1},"primary-ink-hover":{"r":0.3843137254901961,"g":0.7137254901960784,"b":0.5176470588235295,"a":1},"success":{"r":0.3215686274509804,"g":0.7686274509803922,"b":0.10196078431372549,"a":1},"success-light-3":{"r":0.5254901960784314,"g":0.8392156862745098,"b":0.37254901960784315,"a":1},"success-light-7":{"r":0.796078431372549,"g":0.9294117647058824,"b":0.7294117647058823,"a":1},"success-light-9":{"r":0.9333333333333333,"g":0.9764705882352941,"b":0.9098039215686274,"a":1},"success-dark-1":{"r":0.2901960784313726,"g":0.6901960784313725,"b":0.09019607843137255,"a":1},"success-dark-3":{"r":0.2235294117647059,"g":0.5372549019607843,"b":0.07058823529411765,"a":1},"success-dark-7":{"r":0.09803921568627451,"g":0.23137254901960785,"b":0.03137254901960784,"a":1},"success-dark-9":{"r":0.03137254901960784,"g":0.0784313725490196,"b":0.011764705882352941,"a":1},"success-soft":{"r":0.03137254901960784,"g":0.0784313725490196,"b":0.011764705882352941,"a":1},"success-soft-hover":{"r":0.09803921568627451,"g":0.23137254901960785,"b":0.03137254901960784,"a":1},"success-soft-active":{"r":0.09803921568627451,"g":0.23137254901960785,"b":0.03137254901960784,"a":1},"success-border":{"r":0.09803921568627451,"g":0.23137254901960785,"b":0.03137254901960784,"a":1},"success-ink":{"r":0.3215686274509804,"g":0.7686274509803922,"b":0.10196078431372549,"a":1},"on-success":{"r":1,"g":1,"b":1,"a":1},"danger":{"r":1,"g":0.30196078431372547,"b":0.30980392156862746,"a":1},"danger-light-3":{"r":1,"g":0.5098039215686274,"b":0.5176470588235295,"a":1},"danger-light-7":{"r":1,"g":0.792156862745098,"b":0.792156862745098,"a":1},"danger-light-9":{"r":1,"g":0.9294117647058824,"b":0.9294117647058824,"a":1},"danger-dark-1":{"r":0.9019607843137255,"g":0.27058823529411763,"b":0.2784313725490196,"a":1},"danger-dark-3":{"r":0.7019607843137254,"g":0.21176470588235294,"b":0.21568627450980393,"a":1},"danger-dark-7":{"r":0.30196078431372547,"g":0.09019607843137255,"b":0.09411764705882353,"a":1},"danger-dark-9":{"r":0.10196078431372549,"g":0.03137254901960784,"b":0.03137254901960784,"a":1},"danger-soft":{"r":0.10196078431372549,"g":0.03137254901960784,"b":0.03137254901960784,"a":1},"danger-soft-hover":{"r":0.30196078431372547,"g":0.09019607843137255,"b":0.09411764705882353,"a":1},"danger-soft-active":{"r":0.30196078431372547,"g":0.09019607843137255,"b":0.09411764705882353,"a":1},"danger-border":{"r":0.30196078431372547,"g":0.09019607843137255,"b":0.09411764705882353,"a":1},"danger-ink":{"r":1,"g":0.5098039215686274,"b":0.5176470588235295,"a":1},"on-danger":{"r":1,"g":1,"b":1,"a":1},"danger-active":{"r":0.9019607843137255,"g":0.27058823529411763,"b":0.2784313725490196,"a":1},"danger-hover":{"r":1,"g":0.37254901960784315,"b":0.3803921568627451,"a":1},"warning":{"r":0.9803921568627451,"g":0.6784313725490196,"b":0.0784313725490196,"a":1},"warning-light-3":{"r":0.9882352941176471,"g":0.7764705882352941,"b":0.3568627450980392,"a":1},"warning-light-7":{"r":0.996078431372549,"g":0.9019607843137255,"b":0.7254901960784313,"a":1},"warning-light-9":{"r":1,"g":0.9686274509803922,"b":0.9098039215686274,"a":1},"warning-dark-1":{"r":0.8823529411764706,"g":0.611764705882353,"b":0.07058823529411765,"a":1},"warning-dark-3":{"r":0.6862745098039216,"g":0.4745098039215686,"b":0.054901960784313725,"a":1},"warning-dark-7":{"r":0.29411764705882354,"g":0.20392156862745098,"b":0.023529411764705882,"a":1},"warning-dark-9":{"r":0.09803921568627451,"g":0.06666666666666667,"b":0.00784313725490196,"a":1},"warning-soft":{"r":0.09803921568627451,"g":0.06666666666666667,"b":0.00784313725490196,"a":1},"warning-soft-hover":{"r":0.29411764705882354,"g":0.20392156862745098,"b":0.023529411764705882,"a":1},"warning-soft-active":{"r":0.29411764705882354,"g":0.20392156862745098,"b":0.023529411764705882,"a":1},"warning-border":{"r":0.29411764705882354,"g":0.20392156862745098,"b":0.023529411764705882,"a":1},"warning-ink":{"r":0.9803921568627451,"g":0.6784313725490196,"b":0.0784313725490196,"a":1},"on-warning":{"r":1,"g":1,"b":1,"a":1},"info":{"r":0.08627450980392157,"g":0.4666666666666667,"b":1,"a":1},"info-light-3":{"r":0.3607843137254902,"g":0.6274509803921569,"b":1,"a":1},"info-light-7":{"r":0.7254901960784313,"g":0.8392156862745098,"b":1,"a":1},"info-light-9":{"r":0.9098039215686274,"g":0.9450980392156862,"b":1,"a":1},"info-dark-1":{"r":0.0784313725490196,"g":0.4196078431372549,"b":0.9019607843137255,"a":1},"info-dark-3":{"r":0.058823529411764705,"g":0.3254901960784314,"b":0.7019607843137254,"a":1},"info-dark-7":{"r":0.027450980392156862,"g":0.1411764705882353,"b":0.30196078431372547,"a":1},"info-dark-9":{"r":0.00784313725490196,"g":0.047058823529411764,"b":0.10196078431372549,"a":1},"info-soft":{"r":0.00784313725490196,"g":0.047058823529411764,"b":0.10196078431372549,"a":1},"info-soft-hover":{"r":0.027450980392156862,"g":0.1411764705882353,"b":0.30196078431372547,"a":1},"info-soft-active":{"r":0.027450980392156862,"g":0.1411764705882353,"b":0.30196078431372547,"a":1},"info-border":{"r":0.027450980392156862,"g":0.1411764705882353,"b":0.30196078431372547,"a":1},"info-ink":{"r":0.7254901960784313,"g":0.8392156862745098,"b":1,"a":1},"on-info":{"r":1,"g":1,"b":1,"a":1}}};
const leafDensity = {"comfortable":{"control-height":34,"spacing":8,"density-form-gap":16,"density-label-gap":6,"density-row-padding":12,"density-option-height":30,"density-option-padding":6,"density-field-padding":10,"density-dialog-block":20,"density-dialog-inline":24,"density-dialog-gap":16},"compact":{"control-height":30,"spacing":6,"density-form-gap":12,"density-label-gap":4,"density-row-padding":8,"density-option-height":26,"density-option-padding":4,"density-field-padding":8,"density-dialog-block":16,"density-dialog-inline":20,"density-dialog-gap":12}};

/* global figma, leafPalettes, leafDensity */
async function importLeafResources() {
  const fonts = await figma.listAvailableFontsAsync();
  const family = ['Inter', ...new Set(fonts.map((item) => item.fontName.family))].find((name) =>
    ['Regular', 'Medium', 'Bold'].every((style) =>
      fonts.some((item) => item.fontName.family === name && item.fontName.style === style),
    ),
  );
  if (!family) throw new Error('A font family with Regular, Medium and Bold is required.');
  const weights = Object.fromEntries(
    [
      [400, 'Regular'],
      [500, 'Medium'],
      [700, 'Bold'],
    ].map(([weight, style]) => [weight, { family, style }]),
  );
  await Promise.all(Object.values(weights).map((font) => figma.loadFontAsync(font)));
  const colors = figma.variables.createVariableCollection('Leaf / Color');
  colors.renameMode(colors.defaultModeId, 'Light');
  const dark = colors.addMode('Dark');
  const variables = {};
  for (const key of Object.keys(leafPalettes.light)) {
    const variable = figma.variables.createVariable(key, colors, 'COLOR');
    variable.setValueForMode(colors.defaultModeId, leafPalettes.light[key]);
    variable.setValueForMode(dark, leafPalettes.dark[key]);
    variables[key] = variable;
  }
  const pressedBackground = figma.variables.createVariable(
    'button-outline-active-background',
    colors,
    'COLOR',
  );
  for (const [mode, id] of [
    ['light', colors.defaultModeId],
    ['dark', dark],
  ]) {
    const surface = leafPalettes[mode].surface;
    const muted = leafPalettes[mode]['surface-muted'];
    pressedBackground.setValueForMode(id, {
      r: (surface.r + muted.r) / 2,
      g: (surface.g + muted.g) / 2,
      b: (surface.b + muted.b) / 2,
      a: 1,
    });
  }
  variables['button-outline-active-background'] = pressedBackground;
  const textHover = figma.variables.createVariable('button-text-hover-background', colors, 'COLOR');
  for (const [mode, id] of [
    ['light', colors.defaultModeId],
    ['dark', dark],
  ]) {
    const gray = leafPalettes[mode]['option-hover'];
    textHover.setValueForMode(id, { ...gray, a: gray.a * 0.5 });
  }
  variables['button-text-hover-background'] = textHover;
  const density = figma.variables.createVariableCollection('Leaf / Density');
  density.renameMode(density.defaultModeId, 'Comfortable');
  const compact = density.addMode('Compact');
  const dimensions = {};
  for (const key of Object.keys(leafDensity.comfortable)) {
    const variable = figma.variables.createVariable(key, density, 'FLOAT');
    variable.setValueForMode(density.defaultModeId, leafDensity.comfortable[key]);
    variable.setValueForMode(compact, leafDensity.compact[key]);
    dimensions[key] = variable;
  }
  const page = figma.createPage();
  page.name = 'Leaf UI / Components';
  await figma.setCurrentPageAsync(page);
  const paint = (key) =>
    figma.variables.setBoundVariableForPaint(
      { type: 'SOLID', color: { r: 0, g: 0, b: 0 } },
      'color',
      variables[key],
    );
  const label = (name, key = 'text', weight = 500) => {
    const node = figma.createText();
    node.fontName = weights[weight];
    node.fontSize = 14;
    node.characters = name;
    node.fills = [paint(key)];
    return node;
  };
  const buttons = [];
  for (const [index, mode] of ['comfortable', 'compact'].entries()) {
    for (const [row, variant] of ['solid', 'outline', 'text', 'link'].entries()) {
      for (const [col, state] of ['default', 'hover', 'pressed', 'disabled'].entries()) {
        const component = figma.createComponent();
        component.name = `Variant=${variant}, State=${state}, Density=${mode}`;
        component.layoutMode = 'HORIZONTAL';
        component.primaryAxisAlignItems = 'CENTER';
        component.counterAxisAlignItems = 'CENTER';
        component.primaryAxisSizingMode = 'FIXED';
        component.counterAxisSizingMode = 'FIXED';
        component.resize(136, leafDensity[mode]['control-height']);
        component.cornerRadius = 8;
        component.setExplicitVariableModeForCollection(
          density,
          index ? compact : density.defaultModeId,
        );
        component.setBoundVariable('height', dimensions['control-height']);
        const background =
          variant === 'solid'
            ? state === 'pressed'
              ? 'primary-active'
              : 'primary'
            : variant === 'outline'
              ? state === 'pressed'
                ? 'button-outline-active-background'
                : 'surface'
              : variant === 'text' && (state === 'hover' || state === 'pressed')
                ? state === 'hover'
                  ? 'button-text-hover-background'
                  : 'option-hover'
                : null;
        component.fills = background ? [paint(background)] : [];
        if (variant === 'outline') {
          component.strokes = [
            paint(
              state === 'pressed' ? 'border-hover' : state === 'hover' ? 'border-hover' : 'border',
            ),
          ];
          component.strokeWeight = 1;
          component.effects = [
            {
              type: 'DROP_SHADOW',
              color: { r: 0, g: 0, b: 0, a: 0.06 },
              offset: { x: 0, y: 1 },
              radius: 1,
              spread: 0,
              visible: true,
              blendMode: 'NORMAL',
            },
          ];
        }
        component.appendChild(
          label(
            'Button',
            variant === 'solid' ? 'on-primary' : variant === 'link' ? 'primary-ink' : 'text',
          ),
        );
        if (state === 'disabled') component.opacity = 0.45;
        component.x = col * 164;
        component.y = (index * 5 + row) * 68;
        page.appendChild(component);
        buttons.push(component);
      }
    }
  }
  const buttonSet = figma.combineAsVariants(buttons, page);
  buttonSet.name = 'Leaf / Button';
  buttonSet.x = 32;
  buttonSet.y = 80;
  const inputs = [];
  for (const [index, mode] of ['comfortable', 'compact'].entries()) {
    for (const [col, state] of ['default', 'focus', 'error', 'disabled'].entries()) {
      const component = figma.createComponent();
      component.name = `State=${state}, Density=${mode}`;
      component.layoutMode = 'HORIZONTAL';
      component.primaryAxisAlignItems = 'MIN';
      component.counterAxisAlignItems = 'CENTER';
      component.primaryAxisSizingMode = 'FIXED';
      component.counterAxisSizingMode = 'FIXED';
      component.paddingLeft = leafDensity[mode]['density-field-padding'];
      component.resize(240, leafDensity[mode]['control-height']);
      component.cornerRadius = 8;
      component.fills = [paint('surface')];
      component.strokes = [
        paint(state === 'error' ? 'danger' : state === 'focus' ? 'primary' : 'border'),
      ];
      component.appendChild(
        label('Field value', state === 'disabled' ? 'text-muted' : 'text', 400),
      );
      component.setExplicitVariableModeForCollection(
        density,
        index ? compact : density.defaultModeId,
      );
      component.setBoundVariable('height', dimensions['control-height']);
      if (state === 'disabled') component.opacity = 0.55;
      component.x = col * 264;
      component.y = index * 68;
      page.appendChild(component);
      inputs.push(component);
    }
  }
  const inputSet = figma.combineAsVariants(inputs, page);
  inputSet.name = 'Leaf / Input';
  inputSet.x = 32;
  inputSet.y = 720;
  const title = label('Leaf UI · Editable variables and component variants', 'text', 700);
  title.fontSize = 24;
  title.x = 32;
  title.y = 24;
  page.appendChild(title);
  figma.viewport.scrollAndZoomIntoView([buttonSet, inputSet]);
  figma.closePlugin('Leaf variables and editable Button/Input variants created.');
}
importLeafResources().catch((error) => figma.closePlugin(String(error)));
